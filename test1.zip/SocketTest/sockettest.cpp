#include "sockettest.h"
#include "ui_sockettest.h"
#define address "127.0.0.1"
#define port 9999



sockettest::sockettest(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::sockettest)
{
   //connect(socket, SIGNAL(readyRead()),this, SLOT(readyRead()));
    ui->setupUi(this);
    this->centralWidget()->setStyleSheet("background-image:blue;");

}

sockettest::~sockettest()
{
    delete ui;
}
void sockettest::connectServer()
{
    //connect
    socket = new QTcpSocket(this);
    socket->connectToHost(address,port);
    if(socket->waitForConnected(3000))
    {
        socket->waitForReadyRead(3000);
        qDebug() << "reading"<< socket->bytesAvailable() ;
        if (socket->bytesAvailable() > 0)
        {
           qDebug() << socket->readAll();
        }
    }
    else
    {
        qDebug()<< "can't connected";
    }
    socket->write("hello server");
    socket->flush();
    socket->waitForBytesWritten(1000);
}



void sockettest::on_btnLock_clicked()
{
    if(ui->btnLock->text() == "unLock")
    {
        ui->btnLock->setText("lock");
        socket = new QTcpSocket(this);
        socket->connectToHost(address,port);
        if(socket->waitForConnected(3000))
        {
            socket->write("lock door");
            socket->flush();
            socket->waitForBytesWritten(1000);
        }
        else
        {
            qDebug()<< "can't connected";
        }

    }
    else
    {
        ui->btnLock->setText("unLock");
        socket = new QTcpSocket(this);
        socket->connectToHost(address,port);
        if(socket->waitForConnected(3000))
        {
            socket->write("unlock door");
            socket->flush();
            socket->waitForBytesWritten(1000);
        }
        else
        {
            qDebug()<< "can't connected";
        }

    }
}

void sockettest::on_btnVideo_clicked()
{
    if(ui->btnVideo->text() == "stopVideo")
    {
        ui->btnVideo->setText("playVideo");
        socket = new QTcpSocket(this);
        socket->connectToHost(address,port);
        if(socket->waitForConnected(300))
        {
            socket->write("display video");
            socket->waitForBytesWritten(100);
            socket->waitForReadyRead(300);
            qDebug() << "reading" << socket->bytesAvailable();
            QFile file("file.png");
            file.open(QIODevice::ReadOnly);
            QDataStream in(&file);    // read the data serialized from the file
            QString str;
            qint32 a;
            in >> str >> a;
             ui->displayVideo->setAutoFillBackground("file.png");

        }
        else
        {
            qDebug()<< "can't connected";
        }

    }
    else
    {
        ui->btnVideo->setText("stopVideo");


    }
}



void sockettest::on_btnAudio_clicked()
{
    if(ui->btnAudio->text() == "off")
    {
        ui->btnAudio->setText("on");
        socket = new QTcpSocket(this);
        socket->connectToHost(address,port);
        if(socket->waitForConnected(300))
        {
            socket->write("turn on sound");
            socket->waitForBytesWritten(100);
            socket->waitForReadyRead(300);
            qDebug() << "reading" << socket->bytesAvailable();
            QFile file1("file1.wav");
            file1.open(QIODevice::ReadOnly);
            QDataStream in(&file1);    // read the data serialized from the file
            QString str1;
            qint32 a1;
            in >> str1 >> a1;
            ui->displayVideo->setAutoFillBackground("file1.wav");

        }
        else
        {
            qDebug()<< "can't connected";
        }
    }
    else
    {
        ui->btnAudio->setText("off");
    }
}
