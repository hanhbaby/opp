#ifndef SOCKETTEST_H
#define SOCKETTEST_H
#include "QTcpSocket"
#include "QDebug"
#include "QFile"
#include "QDataStream"
#include <QMainWindow>

namespace Ui {
class sockettest;
}

class sockettest : public QMainWindow
{
    Q_OBJECT

public:
    explicit sockettest(QWidget *parent = 0);
    ~sockettest();
    void connectServer();


private slots:

    void on_btnLock_clicked();

    void on_btnVideo_clicked();

public slots:

private:
    Ui::sockettest *ui;

    QTcpSocket *socket;
};

#endif // SOCKETTEST_H
