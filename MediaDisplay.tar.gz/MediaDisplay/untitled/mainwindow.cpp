#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QCamera"
#include "QCameraViewfinder"
#include "QCameraImageCapture"
#include "QVBoxLayout"
#include "QMenu"
#include "QAction"
#include "QFileDialog"
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    mCamera = new QCamera(this);
    mCameraViewfinder = new QCameraViewfinder(this);
    mCameraImageCapture = new QCameraImageCapture(mCamera,this);
    mLayout = new QVBoxLayout;

    mOptionMenu = new QMenu("Option",this);
    mTurnOnAction = new QAction("TurnOn",this);
    mTurnOffAction = new QAction("TurnOff",this);
    mCaptureAction = new QAction("Capture",this);
    mOptionMenu->addActions({ mTurnOnAction, mTurnOffAction,mCaptureAction});
    ui->optionPushButton->setMenu(mOptionMenu);
    mCamera->setViewfinder(mCameraViewfinder);
    mLayout->addWidget(mCameraViewfinder);
    mLayout->setMargin(0);

    ui->scrollArea->setLayout(mLayout);
    connect(mTurnOnAction, &QAction::triggered, [&]() {
        mCamera->start();
    });
    connect(mTurnOffAction, &QAction::triggered, [&]() {
        mCamera->stop();
    });
    connect(mCaptureAction, &QAction::triggered, [&]() {
        auto filename = QFileDialog::getSaveFileName(this,"Capture","/","image (*.jpg, *.jpeg)");
        if(filename.isEmpty())
        {
            return;
        }

        mCameraImageCapture->setCaptureDestination(QCameraImageCapture::CaptureToFile);
        QImageEncoderSettings imageEncoderSetings;
        imageEncoderSetings.setCodec("image/jpeg");
        imageEncoderSetings.setResolution(1200,1000);
        mCameraImageCapture->setEncodingSettings(imageEncoderSetings);
        mCamera->setCaptureMode(QCamera::CaptureStillImage);
        mCamera->start();
        mCamera->searchAndLock();
        mCameraImageCapture->capture(filename);
        mCamera->unlock();


    });

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_btnUnlock_clicked()
{
    if(ui->btnUnlock->text() == "Unlock")
    {
        ui->btnUnlock->setText("Lock");
    }
    else
    {
        ui->btnUnlock->setText("Unlock");
    }
}



